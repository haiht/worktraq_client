<?php if(!isset($v_sval)) die();?>
<div id="page">
<?php echo $v_dsp_tb_region;?>
</div>